create trigger user_and_role
  after INSERT
  on user
  for each row
  begin
insert into user_and_role values(new.user_id,1);
end;

